const form = document.getElementById("symptomForm");
const input = document.getElementById("symptoms");
const result = document.getElementById("result");

document.querySelectorAll(".chip").forEach(btn => {
  btn.addEventListener("click", () => {
    input.value = btn.dataset.value;
    input.focus();
  });
});

function esc(value) {
  return String(value).replace(/[&<>"']/g, ch => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;"
  }[ch]));
}

function renderResult(data) {
  const guide = data.guide || data;
  let html = `<p class="eyebrow">${data.urgent ? "URGENT SAFETY NOTICE" : data.unknown ? "GUIDANCE" : "PRIMARY CARE GUIDE"}</p>`;
  html += `<h3>${esc(guide.title || "Guidance")}</h3><p>${esc(guide.summary || "")}</p>`;
  if (data.urgent) html += `<p class="alert"><strong>Possible emergency:</strong></p>`;
  const sections = [["care","First steps"],["avoid","Things to avoid"],["red","Warning signs"]];
  sections.forEach(([key,label]) => {
    if (guide[key] && guide[key].length) {
      html += `<p><strong>${label}</strong></p><ul>${guide[key].map(x => `<li>${esc(x)}</li>`).join("")}</ul>`;
    }
  });
  if (guide.medicine) html += `<p><strong>Medicine safety</strong><br>${esc(guide.medicine)}</p>`;
  html += `<p class="tiny">This is general educational information, not a diagnosis or personal treatment plan. Consult a qualified healthcare professional.</p>`;
  result.innerHTML = html;
}

form.addEventListener("submit", async event => {
  event.preventDefault();
  const symptoms = input.value.trim();
  if (!symptoms) {
    result.innerHTML = '<p class="eyebrow">INPUT NEEDED</p><h3>Please describe your symptom.</h3>';
    return;
  }
  result.innerHTML = '<p class="eyebrow">CHECKING</p><h3>Preparing general guidance…</h3>';
  try {
    const response = await fetch("/guide", {
      method: "POST",
      headers: {"Content-Type":"application/x-www-form-urlencoded"},
      body: new URLSearchParams({symptoms})
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Unable to process request.");
    renderResult(data);
  } catch (err) {
    result.innerHTML = `<p class="eyebrow">ERROR</p><h3>${esc(err.message)}</h3>`;
  }
});

// Lightweight decorative particle field; respects reduced-motion preferences.
if (!window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
  const field = document.getElementById("particles");
  for (let i = 0; i < 130; i++) {
    const dot = document.createElement("i");
    dot.style.cssText = `position:absolute;left:${Math.random()*100}%;top:${Math.random()*100}%;width:${Math.random()*2+1}px;height:${Math.random()*2+1}px;border-radius:50%;background:${Math.random()>.5?"#4ce0bd":"#d96b88"};opacity:${Math.random()*.65+.15}`;
    field.appendChild(dot);
  }
}
